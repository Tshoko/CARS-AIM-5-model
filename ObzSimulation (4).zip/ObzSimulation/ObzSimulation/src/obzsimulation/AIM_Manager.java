/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;

/**
 *
 * @author Boitshoko
 */
public class AIM_Manager {
    Graphics2D graphics;
    int time,robot,legtime;
    boolean state,collision;
    
    
    public AIM_Manager(int robot){
        
        time=0;
        legtime=0;
        this.robot=robot;
        state=true;
	}
     public Rectangle bounds(int x,int y,int sizex,int sizey){
         /*
       switch (id) {
            case 1:  return(new Rectangle(560, 355, 80, 80));
            case 2:  return(new Rectangle(560, 275, 80, 80));
            case 3:  return(new Rectangle(640, 275, 80, 80));
            case 4:  return(new Rectangle(640, 355, 80, 80));
            default: return null;
       }*/
        return(new Rectangle(x,y,sizex,sizey));
    }
     
     public void checkCollision(Vehicle car){
       Rectangle r1 = car.bounds();
       
       for(int j=275;j<435;j=j+40){
           for(int i=560;i<720;i=i+40){
               //graphics.setColor(Color.white);
               //graphics.fillRect(i,j, 80, 80);
               Rectangle r2 = this.bounds(i,j,40,40);
               if (r1.intersects(r2)){
                  collision=true;
                  graphics.setColor(Color.white);
                  graphics.fillRect(r1.x,r1.y, 40, 40);
                  
                 }
           }
       }
     }
        
    
    public void update(Graphics g,Vehicle car,TrafficLight traffic){
          graphics=(Graphics2D) g;
          /*
          graphics.setColor(Color.WHITE);
          graphics.fillRect(560, 355, 80, 80);
          
          graphics.setColor(Color.yellow);
          graphics.fillRect(560, 275, 80, 80);
          
          graphics.setColor(Color.blue);
          graphics.fillRect(640, 275, 80, 80);
          
          graphics.setColor(Color.RED);
          graphics.fillRect(640, 355, 80, 80);legtime=0;*/
          
          
          this.checkCollision(car);
        int Simulate = this.Simulate(car, traffic);
        
        
       
    }
    public int Simulate(Vehicle car,TrafficLight traffic){
        Vehicle car2=new Vehicle(car.x,car.y,car.speed,car.id,car.direction,car.destination);
        int count=0;
        if(car.passed &&!(car.simulated)){
            car.setSimulated(true);
        while(!car2.done){
            car2.Move(car2.direction, graphics, traffic);
            count++;
            if(count>100){
                break;
            }
            
        }}
        graphics.drawString(String.valueOf(count), 30, 30);
        return count;
    }
    public boolean getState(){
        return state;
    }
    public void CountTime(){
        time++;
    }
    public void CountLeg(){
        legtime++;
    }
}
