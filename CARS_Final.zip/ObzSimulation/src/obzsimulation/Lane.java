/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author mshsit002
 */
public class Lane {
    
       Random rn = new Random() ;
    BufferedImage Terrain = null ; 
    
    BufferedImage Car = null ; 
   
    boolean t=true;
    
    TrafficLight traffic;
    
    Graphics2D graphics;
    
    Vehicle vehicle;
    
    ArrayList<Vehicle> LaneWest,LaneEast,all,LaneSouth,LaneNorth;
    ArrayList<Vehicle> LaneWest1,LaneEast1,LaneSouth1,LaneNorth1;
    point west1,west2,east1,east2,north1,north2,south1,south2;
    
    Vehicle vec2,vec3  ;
    
    int time = 0 ;
    AIM_Manager AIM;
    int RobotTime = 10 ;
    int x = 0 ;
    
    int y = 390 ,countLaneWest,countLaneEast,countLaneSouth,prob,countLaneNorth;
    int countLaneWest1,countLaneEast1,countLaneSouth1,countLaneNorth1;
    public Lane(){
        LaneWest=new ArrayList<Vehicle>();
      LaneEast=new ArrayList<Vehicle>();
      LaneSouth=new ArrayList<Vehicle>();
      LaneNorth=new ArrayList<Vehicle>();
      
      LaneWest1=new ArrayList<Vehicle>();
      LaneEast1=new ArrayList<Vehicle>();
      LaneSouth1=new ArrayList<Vehicle>();
      LaneNorth1=new ArrayList<Vehicle>();
      all=new ArrayList<Vehicle>();
      //this.AIM=AIM;
      AIM = new AIM_Manager(80);
      countLaneWest=4000;
      countLaneEast=0;
      countLaneSouth=100000;
      countLaneNorth=1000000000;
      
      countLaneWest=-4000;
      countLaneEast=-1;
      countLaneSouth=-100000;
      countLaneNorth=-1000000000;
      prob=20;
      west1=new point(0,410);
      west2=new point(0,370);
      south2=new point(660,715);
      south1=new point(700,715);
      east1=new point(1275,300);
      east2=new point(1275,330);
      north1=new point(585,0);
      north2=new point(620,0);
      
      
    }
    
    public void update(Graphics graphics){
        this.graphics=(Graphics2D) graphics;
        AIM.CountTime();
      lanewest();
      laneeast();
     
      lanesouth();
      lanenorth();
    }
    
   public int getRandom(){
     return rn.nextInt(1000);
 }
    
    
   public void lanenorth(){
        
        for(Vehicle car:LaneNorth){
             //AIM.update(graphics ,car,true);
            AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car))))
           {
           car.Move("NORTH",graphics,true);
           }
           else{
           car.Move("NORTH",graphics,false);
                   
           }
            }
            else{
                car.Move("NORTH",graphics,false);
            }
           //car.Move("SOUTH",graphics,true);
           for(Vehicle c:LaneNorth){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}

              
          }
      }
        for(Vehicle car:LaneNorth1){
             //AIM.update(graphics ,car,true);
            AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car))))
           {
           car.Move("NORTH",graphics,true);
           }
           else{
           car.Move("NORTH",graphics,false);
                   
           }
            }
            else{
                car.Move("NORTH",graphics,false);
            }
           //car.Move("SOUTH",graphics,true);
           for(Vehicle c:LaneNorth1){
              if(c.id==(car.id+1)){
              car.checkCollision(c);}

              
          }
      }

      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          if(this.getRandom()<500){
          vec3=new Vehicle(north1.x,north1.y+x3,x2,countLaneNorth1,"NORTH","SOUTH");
          LaneNorth1.add(vec3);
          all.add(vec3);
          countLaneNorth1--;}
          else{
          vec3=new Vehicle(north2.x,north2.y+x3,x2,countLaneNorth,"NORTH","SOUTH");
          LaneNorth.add(vec3);
          all.add(vec3);
          countLaneNorth++;
          }
          
       }
      
      
      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(north1.x,north1.y+x3,x2,countLaneNorth1,"NORTH","WEST");
          LaneNorth1.add(vec3);
          all.add(vec3);
          countLaneNorth1--;
          //System.out.println(countLaneSouth+"north");
       }
   
      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15)+1;
          int x3= rn.nextInt(20);
          vec3=new Vehicle(north2.x,north2.y+x3,x2,countLaneNorth,"NORTH","EAST");
          LaneNorth.add(vec3);
          all.add(vec3);
          countLaneNorth++;
         // System.out.println(countLaneSouth+"west");
       }
     
      
    }  
   public void lanesouth(){
        
        for(Vehicle car:LaneSouth){
             //AIM.update(graphics ,car,true);
            AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car))))
           {
           car.Move("SOUTH",graphics,true);
           }
           else{
           car.Move("SOUTH",graphics,false);
                   
           }
            }
            else{
                car.Move("SOUTH",graphics,false);
            }
           for(Vehicle c:LaneSouth){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}
     
          }
      }
     for(Vehicle car:LaneSouth1){
             //AIM.update(graphics ,car,true);
       AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car))))
           {
           car.Move("SOUTH",graphics,true);
           }
           else{
           car.Move("SOUTH",graphics,false);
                   
           }
            }
            else{
                car.Move("SOUTH",graphics,false);
            }
           for(Vehicle c:LaneSouth1){
              if(c.id==(car.id+1)){
              car.checkCollision(c);}
     
          }
      }
      
    
      if(this.getRandom()<prob){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);

       
          
          vec3=new Vehicle(south1.x,south1.y+x3,x2,countLaneSouth1,"SOUTH","EAST");
          LaneSouth1.add(vec3);
          all.add(vec3);
          countLaneSouth1--;
          
       }
       
      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          if(this.getRandom()<500){
          vec3=new Vehicle(south2.x,south2.y+x3,x2,countLaneSouth,"SOUTH","NORTH");
          LaneSouth.add(vec3);
          countLaneSouth++;
          }
          else{
          
          vec3=new Vehicle(south1.x,south1.y+x3,x2,countLaneSouth1,"SOUTH","NORTH");
          LaneSouth1.add(vec3);
          all.add(vec3);
          countLaneSouth1--;
          }
          
       }
       
      if(this.getRandom()<prob){
          
          int x2= rn.nextInt(15)+1;
          int x3= rn.nextInt(20);
          
          
          vec3=new Vehicle(south2.x,south2.y+x3,x2,countLaneSouth,"SOUTH","WEST");
          LaneSouth.add(vec3);
          countLaneSouth++;
          
                   // System.out.println(countLaneSouth+"west");
       }
     
    }  
   public void laneeast(){
        
        for(Vehicle car:LaneEast){
             AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car)))){
           car.Move("EAST",graphics,true);}
           else{
           car.Move("EAST",graphics,false);
                   
           }}
            else{
                car.Move("EAST",graphics,false);
            }
           //car.Move("EAST",graphics,true);
           for(Vehicle c:LaneEast){
              if(c.id==(car.id-1)){
              car.checkCollision(c);} 
          }
      }
      for(Vehicle car:LaneEast1){
             AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car)))){
           car.Move("EAST",graphics,true);}
           else{
           car.Move("EAST",graphics,false);
                   
           }}
            else{
                car.Move("EAST",graphics,false);
            }
           //car.Move("EAST",graphics,true);
           for(Vehicle c:LaneEast1){
              if(c.id==(car.id+1)){
              car.checkCollision(c);} 
          }
      }
     
      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(east2.x-x3,east2.y,x2,countLaneEast,"EAST","SOUTH");
          LaneEast.add(vec3);
          all.add(vec3);
          countLaneEast++;
          System.out.println(countLaneEast+"north");
       }
       
      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(east1.x-x3,east1.y,x2,countLaneEast1,"EAST","NORTH") ;
          LaneEast1.add(new Vehicle(east1.x-x3,east1.y,x2,countLaneEast1,"EAST","NORTH"));
          all.add(vec3);
          countLaneEast1--;
          //System.out.println(countLaneEast+"north");
       }
      
      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15)+1;
          int x3= rn.nextInt(10);
          if(this.getRandom()<500){
          vec3=new Vehicle(east2.x-x3,east2.y,x2,countLaneEast,"EAST","WEST");
          LaneEast.add(vec3);
          all.add(vec3);
          countLaneEast++;
          //System.out.println(countLaneEast+"west");
          }
          else{
              vec3=new Vehicle(east1.x-x3,east1.y,x2,countLaneEast1,"EAST","WEST");
          LaneEast1.add(vec3);
          all.add(vec3);
          countLaneEast1--;
          //System.out.println(countLaneEast+"west");
          }
       }
     
    }
   public void lanewest(){
        
        for(Vehicle car:LaneWest){
            AIM.update(graphics ,car,true);
            
            if(!(AIM.Deque())){
           //     graphics.setColor(Color.yellow);
         // graphics.fillRect(560, 275, 160, 160);
           if((AIM.permission(car))&&!((AIM.Done(car)))){
           car.Move("WEST",graphics,true);}
           else{
           car.Move("WEST",graphics,false);
                   
           }}
            else{
                car.Move("WEST",graphics,false);
            }
          for(Vehicle c:LaneWest){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}
              
          }
          
      }
        
for(Vehicle car:LaneWest1){
            AIM.update(graphics ,car,true);
            
            if(!(AIM.Deque())){
           //     graphics.setColor(Color.yellow);
         // graphics.fillRect(560, 275, 160, 160);
           if((AIM.permission(car))&&!((AIM.Done(car)))){
           car.Move("WEST",graphics,true);}
           else{
           car.Move("WEST",graphics,false);
                   
           }}
            else{
                car.Move("WEST",graphics,false);
            }
          for(Vehicle c:LaneWest1){
              if(c.id==(car.id+1)){
              car.checkCollision(c);}
              
          }
          
      }    
      
      if(this.getRandom()<prob){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          
          if(this.getRandom()<500){
          LaneWest1.add(new Vehicle(west1.x,west1.y,x2,countLaneWest1,"WEST","SOUTH"));
          countLaneWest1--;
          }
          else{
           LaneWest.add(new Vehicle(west2.x,west2.y,x2,countLaneWest,"WEST","SOUTH"));
          countLaneWest++;
              
          }
       }
      
      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          
         
          
           LaneWest.add(new Vehicle(west2.x,west2.y,x2,countLaneWest,"WEST","NORTH"));
          countLaneWest++;
              
         
       }
      
      if(this.getRandom()<prob ){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          if(this.getRandom()<500){
          LaneWest1.add(new Vehicle(west1.x,west1.y,x2,countLaneWest1,"WEST","EAST"));
          countLaneWest1--;
          }
          else{
           LaneWest.add(new Vehicle(west2.x,west2.y,x2,countLaneWest,"WEST","EAST"));
          countLaneWest++;
              
          }
          
       }
    }
    
}
