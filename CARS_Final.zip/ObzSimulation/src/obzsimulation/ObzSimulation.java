/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import static java.lang.Math.random;
import java.util.ArrayList;
import java.util.Random;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author mshsit002
 */
public class ObzSimulation extends JPanel implements ActionListener {
    
    Random rn = new Random() ;
    BufferedImage Terrain = null ; 
    
    BufferedImage Car = null ; 
   
    boolean t=true;
    
    TrafficLight traffic;
    
    Graphics2D graphics;
    
    Vehicle vehicle;
    
    ArrayList<Vehicle> LaneWest,LaneEast,all,LaneSouth,LaneNorth;
    
    Vehicle vec2,vec3  ;
    
    int time = 0 ;
    AIM_Manager AIM;
    int RobotTime = 10 ;
    int x = 0 ;
    Lane lane;
    
    int y = 390 ,countLaneWest,countLaneEast,countLaneSouth,prob,countLaneNorth;
    
    
    
    
    public void paintComponent(Graphics g){
    
      super.paintComponent(g);

        graphics  = (Graphics2D)g ; 

        Dimension size = new Dimension(Terrain.getWidth(null), Terrain.getHeight(null));

        setPreferredSize(size);
        
        setMinimumSize(size);

        setMaximumSize(size);

      setSize(size);
      
      graphics.drawImage(Terrain,0,0,null);
       
      //traffic.update(g);
      
      
      //traffic.CountTime();
      lane.update(graphics);
    
      }

    public ObzSimulation() throws IOException{
    
      Terrain  = ImageIO.read(new File("C:\\Users\\Boitshoko\\Pictures\\WeGetTingThere\\ObzSimulation\\ObzSimulation\\src\\obzsimulation\\maxresdefault.jpg"));
       lane=new Lane();
      
      
      //traffic=new TrafficLight(80);
      
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO code application logic here
        
        JFrame Jframe  =  new JFrame("Jesus Take The wheel"); 
        
        ObzSimulation simulation  = new ObzSimulation();
        
        Jframe.setContentPane(simulation);
        
        Jframe.setSize(1534,772);
        
        Jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Jframe.addMouseListener(new MouseListener() {
        
        public void mousePressed(MouseEvent me) { }
        
        public void mouseReleased(MouseEvent me) { }
        
        public void mouseEntered(MouseEvent me) { }
        
        public void mouseExited(MouseEvent me) { }
        
        public void mouseClicked(MouseEvent me) { 
          
          int x = me.getX();
          
          int y = me.getY();
          
          System.out.println(("X:" + x + " Y:" + y)); 
        }
    });
        
        
        Jframe.setVisible(true);
        
        while(true){
        
            //simulation.moveCarNje();
            
            simulation.repaint();
            
            
            
            Thread.sleep(50);
        
        }
        
        
        
     
        
        
        
        
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        
    }
    
}
