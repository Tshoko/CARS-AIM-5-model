/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.Graphics;

/**
 *
 * @author mshsit002
 */
public class Vechiles {
    
    int x ; 
    
    int y ;
    
    int width ;
    
    int height;
    
    int speed ;
    
    
    public Vechiles( int newx ,  int newy){
    
        x =  newx ;
        
        y = newy  ;
    
    }
    
    public void paintMe(Graphics g){
        
        
        
    }
}
    

}
