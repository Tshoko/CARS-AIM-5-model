    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import static java.lang.Math.random;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author mshsit002
 */
public class ObzSimulation extends JPanel {
    
   
    BufferedImage Terrain = null ; 
    
    BufferedImage Car = null ; 
   
    TrafficLight traffic;
    
    Graphics2D graphics;
    
    Vehicle vehicle;
    
    ArrayList<Vehicle> LaneWest,LaneEast,all,LaneSouth,LaneNorth;
    
    Vehicle vec2,vec3  ;
    
    int time = 0 ;
    
    AIM_Manager AIM;
    
    int RobotTime = 10 ;
    
    int x = 0 ;
    String policy="FCFS";
    Lane lane;
    
    int y = 390 ,countLaneWest,countLaneEast,countLaneSouth,prob,countLaneNorth;
    
    
    
    
    public void paintComponent(Graphics g){
    
      super.paintComponent(g);

      graphics  = (Graphics2D)g ; 

      Dimension size = new Dimension(Terrain.getWidth(null), Terrain.getHeight(null));

      setPreferredSize(size);
        
      setMinimumSize(size);

      setMaximumSize(size);

      setSize(size);
      
      graphics.drawImage(Terrain,0,0,null);
       
      lane.update(graphics);
      lane.setPolicy(policy);
      graphics.drawString("Measure Through Put: "+lane.getDone(), 10, 10);
    
      }

    public ObzSimulation(int speed,int BigProb,String policy) throws IOException{
    
    Terrain  = ImageIO.read(new File("/home/m/mshsit002/Downloads/CARS_Final/ObzSimulation/src/obzsimulation/maxresdefault.jpg"));
      
      lane = new Lane(speed,BigProb,policy);
      this.policy=policy;
     
    }
    public int getDone(){
        return lane.getDone();
    }
    
    public void setPolicy(String policy ){
    
        this.policy = policy  ;
    }

   
    public static void main(String[] args) throws IOException, InterruptedException {
       
        Scanner scanner = new Scanner(System.in);
        
      
        int option = scanner.nextInt(); 
        
        System.out.println("Enter Traffic Volume: <0,10>| vehicles/second/lane\n");
        
        int TrafficLevel = scanner.nextInt();
        
  
        
        int Speed = scanner.nextInt();
        
        JFrame Jframe  =  new JFrame("AIM Viewer"); 
        

        
    }
    
        
    }

        
        
    