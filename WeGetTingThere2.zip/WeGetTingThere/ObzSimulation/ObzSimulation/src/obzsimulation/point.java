/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

/**
 *
 * @author mshsit002
 */
public class point { 
    public int x;   // Cartesian
    public int y;   // coordinates
   
    // create and initialize a point with given (x, y)
    public point(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // return Euclidean distance between invoking point p and q
    public int distanceTo(point that) {
        double dx = this.x - that.x;
        double dy = this.y - that.y;
        return (int)Math.sqrt(dx*dx + dy*dy);
    }



}