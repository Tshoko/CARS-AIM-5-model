/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import static java.lang.Math.random;
import java.util.ArrayList;
import java.util.Random;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author mshsit002
 */
public class ObzSimulation extends JPanel implements ActionListener {
    
    Random rn = new Random() ;
    BufferedImage Terrain = null ; 
    
    BufferedImage Car = null ; 
   
    boolean t=true;
    
    TrafficLight traffic;
    
    Graphics2D graphics;
    
    Vehicle vehicle;
    
    ArrayList<Vehicle> LaneWest,LaneEast,all,LaneSouth,LaneNorth;
    
    Vehicle vec2,vec3  ;
    
    int time = 0 ;
    AIM_Manager AIM;
    int RobotTime = 10 ;
    int x = 0 ;
    
    int y = 390 ,countLaneWest,countLaneEast,countLaneSouth,prob,countLaneNorth;
    
    
    
    
    public void paintComponent(Graphics g){
    
      super.paintComponent(g);

        graphics  = (Graphics2D)g ; 

        Dimension size = new Dimension(Terrain.getWidth(null), Terrain.getHeight(null));

        setPreferredSize(size);
        
        setMinimumSize(size);

        setMaximumSize(size);

      setSize(size);
      
      graphics.drawImage(Terrain,0,0,null);
      
      graphics.drawImage(Car,(int)x,(int)y,null);  
      // AIM.update(g,vehicle,traffic);
      //vehicle.MoveS_E(graphics, traffic.getState());
        
            //lanesouth();
            //lanewest();
            //laneeast();
            //vehicle.MoveW_N(g, tra{ffic.getState());
        
      
      //vec2.MoveW_N(g, traffic.getState());
      
     // vec3.MoveW_N(g, traffic.getState());
      
      //vec3.checkCollision(vec2);
      AIM.CountTime();
      lanewest();
      laneeast();
     
      lanesouth();
      lanenorth();
      //traffic.update(g);
      
      
      //traffic.CountTime();
    
      }
public void lanenorth(){
        
        for(Vehicle car:LaneNorth){
             //AIM.update(graphics ,car,true);
            AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car))))
           {
           car.Move("NORTH",graphics,true);
           }
           else{
           car.Move("NORTH",graphics,false);
                   
           }
            }
            else{
                car.Move("NORTH",graphics,false);
            }
           //car.Move("SOUTH",graphics,true);
           for(Vehicle c:LaneNorth){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}
//            for(Vehicle ca:all){
//                if((Math.abs(ca.x-car.x)<20)||(Math.abs(ca.y-car.y))<20){
//                    car.checkCollision(ca);
//                }
                    
            //}
         
              
          }
      }
      
      int x1 = rn.nextInt(1000);
      //System.out.println(x1);
      
      if(x1<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(600,0+x3,x2,countLaneNorth,"NORTH","SOUTH");
          LaneNorth.add(vec3);
          all.add(vec3);
          countLaneNorth++;
          //System.out.println(countLaneSouth+"north");
       }
      
       x1 = rn.nextInt(1000);
      if(x1<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(600,0+x3,x2,countLaneNorth,"NORTH","WEST");
          LaneNorth.add(vec3);
          all.add(vec3);
          countLaneNorth++;
          //System.out.println(countLaneSouth+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<prob ){
          
          int x2= rn.nextInt(15)+1;
          int x3= rn.nextInt(20);
          vec3=new Vehicle(600,0+x3,x2,countLaneNorth,"NORTH","EAST");
          LaneNorth.add(vec3);
          all.add(vec3);
          countLaneNorth++;
         // System.out.println(countLaneSouth+"west");
       }
     
      
    }  
  public void lanesouth(){
        
        for(Vehicle car:LaneSouth){
             //AIM.update(graphics ,car,true);
            AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car))))
           {
           car.Move("SOUTH",graphics,true);
           }
           else{
           car.Move("SOUTH",graphics,false);
                   
           }
            }
            else{
                car.Move("SOUTH",graphics,false);
            }
           //car.Move("SOUTH",graphics,true);
           for(Vehicle c:LaneSouth){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}
//            for(Vehicle ca:all){
//                if((Math.abs(ca.x-car.x)<20)||(Math.abs(ca.y-car.y))<20){
//                    car.checkCollision(ca);
//                }
                    
            //}
         
              
          }
      }
      
      int x1 = rn.nextInt(1000);
      //System.out.println(x1);
      if(x1<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(670,900+x3,x2,countLaneSouth,"SOUTH","EAST");
          LaneSouth.add(vec3);
          all.add(vec3);
          countLaneSouth++;
          //System.out.println(countLaneSouth+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(670,900+x3,x2,countLaneSouth,"SOUTH","NORTH");
          LaneSouth.add(vec3);
          all.add(vec3);
          countLaneSouth++;
          //System.out.println(countLaneSouth+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<prob ){
          
          int x2= rn.nextInt(15)+1;
          int x3= rn.nextInt(20);
          vec3=new Vehicle(670,900+x3,x2,countLaneSouth,"SOUTH","WEST");
          LaneSouth.add(vec3);
          all.add(vec3);
          countLaneSouth++;
         // System.out.println(countLaneSouth+"west");
       }
     
    }  
    public void laneeast(){
        
        for(Vehicle car:LaneEast){
             AIM.update(graphics ,car,true);
            if(!(AIM.Deque())){
           if((AIM.permission(car))&&!((AIM.Done(car)))){
           car.Move("EAST",graphics,true);}
           else{
           car.Move("EAST",graphics,false);
                   
           }}
            else{
                car.Move("EAST",graphics,false);
            }
           //car.Move("EAST",graphics,true);
           for(Vehicle c:LaneEast){
              if(c.id==(car.id-1)){
              car.checkCollision(c);} 
          }
      }
      
      int x1 = rn.nextInt(1000);
      //System.out.println(x1);
      if(x1<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(1270-x3,305,x2,countLaneEast,"EAST","SOUTH");
          LaneEast.add(vec3);
          all.add(vec3);
          countLaneEast++;
          System.out.println(countLaneEast+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<prob ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(1270-x3,305,x2,countLaneEast,"EAST","NORTH");
          LaneEast.add(vec3);
          all.add(vec3);
          countLaneEast++;
          System.out.println(countLaneEast+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<prob ){
          
          int x2= rn.nextInt(15)+1;
          int x3= rn.nextInt(20);
          vec3=new Vehicle(1270-x3,305,x2,countLaneEast,"EAST","WEST");
          LaneEast.add(vec3);
          all.add(vec3);
          countLaneEast++;
          System.out.println(countLaneEast+"west");
       }
     
    }
    public void lanewest(){
        
        for(Vehicle car:LaneWest){
            AIM.update(graphics ,car,true);
            
            if(!(AIM.Deque())){
           //     graphics.setColor(Color.yellow);
         // graphics.fillRect(560, 275, 160, 160);
           if((AIM.permission(car))&&!((AIM.Done(car)))){
           car.Move("WEST",graphics,true);}
           else{
           car.Move("WEST",graphics,false);
                   
           }}
            else{
                car.Move("WEST",graphics,false);
            }
          for(Vehicle c:LaneWest){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}
              
          }
          
      }
      
      int x1 = rn.nextInt(1000);
      System.out.println(x1);
      if(x1<prob ){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          LaneWest.add(new Vehicle(x3,y,x2,countLaneWest,"WEST","SOUTH"));
          countLaneWest++;
       }
      x1 = rn.nextInt(1000);
      if(x1<prob ){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          LaneWest.add(new Vehicle(x3,y,x2,countLaneWest,"WEST","NORTH"));
          countLaneWest++;
       }
      x1 = rn.nextInt(1000);
      if(x1<prob ){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          LaneWest.add(new Vehicle(x3,y,x2,countLaneWest,"WEST","EAST"));
          countLaneWest++;
       }
    }
    public ObzSimulation() throws IOException{
    
      Terrain  = ImageIO.read(new File("C:\\Users\\Boitshoko\\Downloads\\ObzSimulation\\ObzSimulation\\src\\obzsimulation\\maxresdefault.jpg"));
   
      
      LaneWest=new ArrayList<Vehicle>();
      LaneEast=new ArrayList<Vehicle>();
      LaneSouth=new ArrayList<Vehicle>();
      LaneNorth=new ArrayList<Vehicle>();
      all=new ArrayList<Vehicle>();
      //traffic=new TrafficLight(80);
      AIM = new AIM_Manager(80);
      countLaneWest=4000;
      countLaneEast=0;
      countLaneSouth=100000;
      countLaneNorth=1000000000;
      prob=5;
      //vehicle=new Vehicle(670,900,7,1,"SOUTH","WEST");
      //all.add(vehicle);
      //LaneWest.add(vehicle);
      
      
      
     
      
      
      
        
        
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO code application logic here
        
        JFrame Jframe  =  new JFrame("Jesus Take The wheel"); 
        
        ObzSimulation simulation  = new ObzSimulation();
        
        Jframe.setContentPane(simulation);
        
        Jframe.setSize(1534,772);
        
        Jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Jframe.addMouseListener(new MouseListener() {
        
        public void mousePressed(MouseEvent me) { }
        
        public void mouseReleased(MouseEvent me) { }
        
        public void mouseEntered(MouseEvent me) { }
        
        public void mouseExited(MouseEvent me) { }
        
        public void mouseClicked(MouseEvent me) { 
          
          int x = me.getX();
          
          int y = me.getY();
          
          System.out.println(("X:" + x + " Y:" + y)); 
        }
    });
        
        
        Jframe.setVisible(true);
        
        while(true){
        
            //simulation.moveCarNje();
            
            simulation.repaint();
            
            
            
            Thread.sleep(50);
        
        }
        
        
        
     
        
        
        
        
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        
    }
    
}
