@Override
public void actionPerformed(ActionEvent e) {
    repaint();
    update();
}