/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.lang.Math.*;
/**
 *
 * @author Boitshoko
 */
public class Vehicle {
   int x ; 
    
    int y ,id;
    String direction,destination;
    int width ;
    int height;
    boolean passed,collision;
    int speed ,moving;
    double theta,omega;
    public enum VehicleDirection{NORTH_SOUTH,NORTH_WEST,NORTH_EAST,SOUTH_NORTH,SOUTH_EAST,SOUTH_WEST,WEST_NORTH,WEST_SOUTH,WEST_EAST,EAST_NORTH,EAST_SOUTH,EAST_WEST};
    public Vehicle(int newx,int newy,int speed,int id,String direction,String destination){
        x =  newx ;
        this.id=id;
        y = newy  ;
        this.speed=speed;
        
        
        moving=0;
        passed=false;
        collision=false;
        this.direction=direction;
        this.destination=destination;
        if(this.direction.equals("SOUTH")){
              theta=-1.4;
              }
        else{
                theta=0;
                }
        
        
    }
 public Rectangle bounds(){
        return(new Rectangle(x,y,30,30));
    }
    public boolean checkCollision(Vehicle car){
       Rectangle r1 = car.bounds();
       Rectangle r2 = this.bounds();
                
       if (r1.intersects(r2)){
           collision=true;
           this.setAdjustSpeed(car.getSpeed());
        }
       else{
           collision=false;
           
//           if(x < (500)){
//                 if(speed<10)
//                    speed = speed- 1 ; }
               if(x > (700)){
                 if(speed<15)
                    speed = speed+ 1 ; }
           
       }
    return collision;
    }
public void MoveW_S(Graphics g,boolean red){
      g.setColor(Color.red);
      g.fillOval((int)x,(int)y, 15,15);
      
      if(!collision){
      if(x < (490)){
        x =  x + speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            if(x<585){
              if(red||x>=505){
                 System.out.println(red+" "+x);
                 x+=(int) (4*Math.cos(theta)) ;
                 y +=(int)(4*Math.sin(theta));
                 theta+=0.03;
              }
            }
            else{
                
                y+=5;
            }   
        }
      
    }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveW_N(Graphics g,boolean green){
      g.setColor(Color.red);
      g.fillOval((int)x,(int)y, 15,15);
      if(!collision){
      if(x < (490)){
        x =  x + speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
             
            if(x<680){
              if((green)||(x>=505)){
                 //System.out.println(green+" "+x);
                 x+=(int) (6*Math.cos(theta)) ;
                 y -=(int)(6*Math.sin(theta));
                theta+=0.027;
               
               }
            }
            else{
                
                y-=7;
            }   
        }
     
      }
      else{
          moving++;
          if(moving>20){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveW_E(Graphics g,boolean red){
      g.setColor(Color.red);
      g.fillOval((int)x,(int)y, 15,15);
      if(!collision){
      if(x < (490)){
        x =  x + 10 ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            if(x<680){
              if(red||x>=505){
                 System.out.println(red+" "+x);
                 x+=10;
               }
            }
            else{
                
                x+=5;
            }   
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveE_W(Graphics g,boolean green){
      g.setColor(Color.blue);
      g.fillOval((int)x,(int)y, 15,15);
      if(!collision){
      if(x > (765)){
        x =  x - speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            if(x<=765){
              if(green||x<=700){
                 System.out.println(green+" "+x);
                 x-=speed;
               }
            }
            
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveE_S(Graphics g,boolean green){
      g.setColor(Color.blue);
      g.fillOval((int)x,(int)y, 15,15);
      if(!collision){
      if(x >(765)){
        x =  x -speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            
              if(x>595){
              if(green||x<=700){
                 System.out.println(green+" "+x);
                 x-=(int) (6*Math.cos(theta)) ;
                 y +=(int)(6*Math.sin(theta));
                 theta+=0.03;
              }
            }
            else{
                
                y+=speed;
            }   
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveE_N(Graphics g,boolean green){
      g.setColor(Color.blue);
      g.fillOval((int)x,(int)y, 15,15);
      if(!collision){
      if(x >(765)){
        x =  x -speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            
              if(x>680){
              if(green||x<=700){
                 System.out.println(green+" "+x);
                 x-=(int) (4*Math.cos(theta)) ;
                 y -=(int)(4*Math.sin(theta));
                 theta+=0.027;
              }
            }
            else{
                
                y-=speed;
            }   
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveS_N(Graphics g,boolean red){
      g.setColor(Color.yellow);
      g.fillOval((int)x,(int)y, 15,15);
      if(!collision){
      if(y > (500)){
        y =  y - speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            if(y<=500){
              if(!red||y<=490){
                 System.out.println(red+" "+x);
                 y-=speed;
               }
            }
            
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
      
    }
public void MoveS_W(Graphics g,boolean red){
      g.setColor(Color.yellow);
      g.fillOval((int)x,(int)y, 15,15);
      if(!collision){
      if(y >(500)){
        y =  y -speed ;
        if(speed<10){
            speed+=1;
        }
        
        }
        else{
            
              if(y>=300){
              if(!red||y<=490){
                 System.out.println(red+" "+x);
                 x+=(int) (6*Math.cos(theta)) ;
                 y +=(int)(6*Math.sin(theta));
                 theta-=0.03;
              }
            }
            else{
                
                x-=speed;
            }   
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveS_E(Graphics g,boolean red){
      g.setColor(Color.yellow);
      g.fillOval((int)x,(int)y, 15,15);
      if(!collision){
      if(y >(500)){
        y =  y -speed ;
        if(speed<10){
            speed+=1;
        }
        
        }
        else{
            
              if(y>=390){
              if(!red||y<=490){
                 System.out.println(red+" "+x);
                 x+=(int) (5*Math.cos(theta)) ;
                 y +=(int)(5*Math.sin(theta));
                 theta+=0.03;
              }
            }
            else{
                
                x+=speed;
            }   
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }


public void setAdjustX(int x){
    this.x =  x ; 
}
public void setAdjustY(int y){

      this.y = y;

}
public void setAdjustSpeed(int speed){
    this.speed = speed ;
}
public int getSpeed(){
    return this.speed ; 
}
} 
