/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import static java.lang.Math.random;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author mshsit002
 */
public class ObzSimulation extends JPanel implements ActionListener {
    Random rn = new Random() ;
    BufferedImage Terrain = null ; 
    
    BufferedImage Car = null ; 
   
    boolean t=true;
    
    TrafficLight traffic;
    
    Graphics2D graphics;
    
    Vehicle vehicle;
    
    ArrayList<Vehicle> LaneWest,LaneEast,all,LaneSouth;
    
    Vehicle vec2,vec3  ;
    
    int time = 0 ;
    
    int RobotTime = 10 ;
    int x = 0 ;
    
    int y = 390 ,countLaneWest,countLaneEast,countLaneSouth;
    
    
    
    
    
    public void paintComponent(Graphics g){
    
      super.paintComponent(g);

        graphics  = (Graphics2D)g ; 

        Dimension size = new Dimension(Terrain.getWidth(null), Terrain.getHeight(null));

        setPreferredSize(size);
        
        setMinimumSize(size);

        setMaximumSize(size);

      setSize(size);
      
      graphics.drawImage(Terrain,0,0,null);
      
      graphics.drawImage(Car,(int)x,(int)y,null);  
      
      vehicle.MoveS_E(graphics, traffic.getState());
      lanesouth();
      lanewest();
      laneeast();
      //vehicle.MoveW_N(g, tra{ffic.getState());
      
      //vec2.MoveW_N(g, traffic.getState());
      
     // vec3.MoveW_N(g, traffic.getState());
      
      //vec3.checkCollision(vec2);
      
      //laneeast();
      //lanewest();
      traffic.update(g);
      
      traffic.CountTime();
     
      }
  
  public void lanesouth(){
        
        for(Vehicle car:LaneSouth){
             
           switch(car.destination){
               case "NORTH":
                   car.MoveS_N(graphics, traffic.getState());
                   break;
               case "EAST":
                   car.MoveS_E(graphics, traffic.getState());
                   break;
               case "WEST":
                   car.MoveS_W(graphics, traffic.getState());
                   break;
           }
           for(Vehicle c:LaneSouth){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}
//            for(Vehicle ca:all){
//                if((Math.abs(ca.x-car.x)<20)||(Math.abs(ca.y-car.y))<20){
//                    car.checkCollision(ca);
//                }
                    
            //}
          
           
         
              
          }
      }
      
      int x1 = rn.nextInt(1000);
      //System.out.println(x1);
      if(x1<10 ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(670,900+x3,x2,countLaneSouth,"SOUTH","EAST");
          LaneSouth.add(vec3);
          all.add(vec3);
          countLaneSouth++;
          System.out.println(countLaneSouth+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<30 ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(670,900+x3,x2,countLaneSouth,"SOUTH","NORTH");
          LaneSouth.add(vec3);
          all.add(vec3);
          countLaneSouth++;
          System.out.println(countLaneSouth+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<10 ){
          
          int x2= rn.nextInt(15)+1;
          int x3= rn.nextInt(20);
          vec3=new Vehicle(670,900+x3,x2,countLaneSouth,"SOUTH","WEST");
          LaneSouth.add(vec3);
          all.add(vec3);
          countLaneSouth++;
          System.out.println(countLaneSouth+"west");
       }
     
    }  
    public void laneeast(){
        
        for(Vehicle car:LaneEast){
             
           switch(car.destination){
               case "NORTH":
                   car.MoveE_N(graphics, traffic.getState());
                   break;
               case "SOUTH":
                   car.MoveE_S(graphics, traffic.getState());
                   break;
               case "WEST":
                   car.MoveE_W(graphics, traffic.getState());
                   break;
           }
           for(Vehicle c:LaneEast){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}
//            for(Vehicle ca:all){
//                if((Math.abs(ca.x-car.x)<20)||(Math.abs(ca.y-car.y))<20){
//                    car.checkCollision(ca);
//                }
                    
            //}
          
           
         
              
          }
      }
      
      int x1 = rn.nextInt(1000);
      //System.out.println(x1);
      if(x1<10 ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(1270-x3,305,x2,countLaneEast,"EAST","SOUTH");
          LaneEast.add(vec3);
          all.add(vec3);
          countLaneEast++;
          System.out.println(countLaneEast+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<30 ){
          
          int x2= rn.nextInt(15+1);
          int x3= rn.nextInt(20);
          vec3=new Vehicle(1270-x3,305,x2,countLaneEast,"EAST","NORTH");
          LaneEast.add(vec3);
          all.add(vec3);
          countLaneEast++;
          System.out.println(countLaneEast+"north");
       }
       x1 = rn.nextInt(1000);
      if(x1<20 ){
          
          int x2= rn.nextInt(15)+1;
          int x3= rn.nextInt(20);
          vec3=new Vehicle(1270-x3,305,x2,countLaneEast,"EAST","WEST");
          LaneEast.add(vec3);
          all.add(vec3);
          countLaneEast++;
          System.out.println(countLaneEast+"west");
       }
     
    }
    public void lanewest(){
        
        for(Vehicle car:LaneWest){
           switch(car.destination){
               case "NORTH":
                   car.MoveW_N(graphics, traffic.getState());
                   break;
               case "SOUTH":
                   car.MoveW_S(graphics, traffic.getState());
                   break;
               case "EAST":
                   car.MoveW_E(graphics, traffic.getState());
                   break;
           }
          
           
          for(Vehicle c:LaneWest){
              if(c.id==(car.id-1)){
              car.checkCollision(c);}
              
          }
      }
      
      int x1 = rn.nextInt(1000);
      System.out.println(x1);
      if(x1<20 ){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          LaneWest.add(new Vehicle(x3,y,x2,countLaneWest,"WEST","SOUTH"));
          countLaneWest++;
       }
      if(x1<30 ){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          LaneWest.add(new Vehicle(x3,y,x2,countLaneWest,"WEST","NORTH"));
          countLaneWest++;
       }
      if(x1<20 ){
          
          int x2= rn.nextInt(15);
          int x3= rn.nextInt(20);
          LaneWest.add(new Vehicle(x3,y,x2,countLaneWest,"WEST","EAST"));
          countLaneWest++;
       }
    }
    public ObzSimulation() throws IOException{
    
      Terrain  = ImageIO.read(new File("C:\\Users\\Boitshoko\\Downloads\\ObzSimulation\\ObzSimulation\\src\\obzsimulation\\maxresdefault.jpg"));
      LaneWest=new ArrayList<Vehicle>();
      LaneEast=new ArrayList<Vehicle>();
      LaneSouth=new ArrayList<Vehicle>();
      all=new ArrayList<Vehicle>();
      traffic=new TrafficLight(80);
      countLaneWest=2;
      countLaneEast=2;
      countLaneSouth=2;
      vehicle=new Vehicle(670,900,7,1,"SOUTH","WEST");
      all.add(vehicle);
      //LaneWest.add(vehicle);
      
      
      
      /*
      Car      = ImageIO.read(new File("C:\\Users\\Boitshoko\\Downloads\\ObzSimulation\\ObzSimulation\\src\\obzsimulation\\car3.png"));
      
      AffineTransform tx  = new AffineTransform();
      
      tx.scale(0.51,0.51);

      tx.rotate(0,Car.getWidth()/2,Car.getHeight());
      
      System.out.println(Car.getWidth());
      System.out.println(Car.getHeight());
      AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BICUBIC);
       
      Car = op.filter(Car, null);
      
      */
        
        
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO code application logic here
        
        JFrame Jframe  =  new JFrame("Jesus Take The wheel"); 
        
        ObzSimulation simulation  = new ObzSimulation();
        
        Jframe.setContentPane(simulation);
        
        Jframe.setSize(1534,772);
        
        Jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Jframe.addMouseListener(new MouseListener() {
        
        public void mousePressed(MouseEvent me) { }
        
        public void mouseReleased(MouseEvent me) { }
        
        public void mouseEntered(MouseEvent me) { }
        
        public void mouseExited(MouseEvent me) { }
        
        public void mouseClicked(MouseEvent me) { 
          
          int x = me.getX();
          
          int y = me.getY();
          
          System.out.println(("X:" + x + " Y:" + y)); 
        }
    });
        
        
        Jframe.setVisible(true);
        
        while(true){
        
            //simulation.moveCarNje();
            
            simulation.repaint();
            
            
            
            Thread.sleep(100);
        
        }
        
        
        
     
        
        
        
        
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        
    }
    
}
