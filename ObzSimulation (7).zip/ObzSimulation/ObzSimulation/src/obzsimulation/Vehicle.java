/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.AffineTransform;
import java.awt.geom.Path2D;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import static java.lang.Byte.SIZE;
import java.lang.Math.*;
import javax.imageio.ImageIO;
/**
 *
 * @author Boitshoko
 */
public class Vehicle {
   int x ; 
    
    int y ,id;
    String direction,destination;
    int width ;
    int height;
    boolean passed,collision,done,simulated,intersection,requested;
    int speed ,moving;
    double theta,omega,xscale,yscale;
    public enum VehicleDirection{NORTH_SOUTH,NORTH_WEST,NORTH_EAST,SOUTH_NORTH,SOUTH_EAST,SOUTH_WEST,WEST_NORTH,WEST_SOUTH,WEST_EAST,EAST_NORTH,EAST_SOUTH,EAST_WEST};
    public Vehicle(int newx,int newy,int speed,int id,String direction,String destination){
        x =  newx ;
        this.id=id;
        y = newy  ;
        intersection=false;
        requested=false;
        this.speed=speed;
        xscale=0.51;
        yscale=0.51;
        simulated=false;
        this.width=30;
        this.height=20;
        moving=0;
        passed=false;
        collision=false;
        this.direction=direction;
        this.destination=destination;
        
        if(this.direction.equals("SOUTH")){
              theta=Math.toRadians(270);
              }
        else{
                theta=0;
                }
        
       omega=theta;   
    }
 public void setIntersection(boolean intersection){
     this.intersection=intersection;
 }
 public void setrequstested(boolean requested){
     this.requested=requested;
 }
 public void display(Graphics g){
     Graphics2D g2d = (Graphics2D)g;
    g2d.setColor(Color.RED);
    AffineTransform old = g2d.getTransform();
    omega=omega;
    g2d.rotate(omega, x, y); 
    g2d.fillRect((int)x, (int)y, 30, 20);
   //g.fillRect(490, 240, 310, 310);
    g2d.setTransform(old);
 }
 public Rectangle bounds(){
        if(this.direction.equals("SOUTH")){
            return(new Rectangle(x,y,40, 40));
        }
        return(new Rectangle(x,y,40, 40));
    }
public Rectangle size(){
    return(new Rectangle(x,y,30, 25));
}
 public void setSimulated(boolean simulated){
     this.simulated=simulated;
 }
    public boolean checkCollision(Vehicle car){
       Rectangle r1 = car.bounds();
       Rectangle r2 = this.bounds();
                
       if (r1.intersects(r2)){
           collision=true;
           this.setAdjustSpeed(car.getSpeed());
        }
       else{
           collision=false;
           
//           if(x < (500)){
//                 if(speed<10)
//                    speed = speed- 1 ; }
               if(x > (700)){
                 if(speed<15)
                    speed = speed+ 1 ; }
           
       }
    return collision;
    }
public void Move(String lane,Graphics g,boolean Go){
    switch(lane){
        case "WEST":
            switch(this.destination){
               case "NORTH":
                   this.MoveW_N(g, Go);
                   break;
               case "SOUTH":
                   this.MoveW_S(g, Go);
                   break;
               case "EAST":
                   this.MoveW_E(g, Go);
                   break;
           }
           break;
       case"SOUTH":
           switch(this.destination){
               case "NORTH":
                   this.MoveS_N(g, Go);
                   break;
               case "EAST":
                   this.MoveS_E(g, Go);
                   break;
               case "WEST":
                   this.MoveS_W(g, Go);
                   break;
           }
           break;
          
        case "EAST":
              switch(this.destination){
               case "NORTH":
                   this.MoveE_N(g, Go);
                   break;
               case "SOUTH":
                   this.MoveE_S(g, Go);
                   break;
               case "WEST":
                   this.MoveE_W(g, Go);
                   break;
           }
           break;
         }
        this.display(g);  
}
public boolean Request(){
     Rectangle r1=new Rectangle(490, 240, 290, 270);
     
     Rectangle r2=this.bounds();
      return r1.intersects(r2);
    
}
public void MoveW_S(Graphics g,boolean GO){
       //BufferedImage Car = ImageIO.read(new File("C:\\Users\\Boitshoko\\Downloads\\ObzSimulation\\ObzSimulation\\src\\obzsimulation\\car3.png"));
      
      //AffineTransform tx  = new AffineTransform();
      
      //tx.scale(xscale,yscale);

      //Rectangle r=this.bounds();
      // draws the player
    
       double orientation = 0;
    
    
      
      if(!collision){
      if(x < (490)){
        x =  (int) (x + speed*Math.cos(theta)/2) ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            if(x<585){
              if(GO||x>=500){
                 //System.out.println(red+" "+x);
                 x+=(int) (4*Math.cos(theta)) ;
                 y+=(int)(4*Math.sin(theta));
                 theta+=0.03;
                 omega+=0.04;
                 passed=true;
                 //tx.rotate(omega,Car.getWidth()/2,Car.getHeight());
                 
              }
            }
            else{
                if(omega<(Math.toRadians(90)))
                {
                omega+=0.06;
                done=true;
                x+=(int) (4*Math.cos(theta)) ;
                y+=(int)(4*Math.sin(theta));
                theta+=0.03;
                System.out.print(theta);
                }
                else{
                    y+=speed;
                    
                }
                
                //tx.rotate(omega,Car.getWidth()/2,Car.getHeight());
            }   
        }
      
    }
      
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveW_N(Graphics g,boolean GO){
      
      if(!collision){
      if(x < (490)){
        x =  x + speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
             
            if(x<680){
              if((GO)||(x>=505)){
                 
                 x+=(int) (6*Math.cos(theta)) ;
                 y -=(int)(6*Math.sin(theta));
                theta+=0.027;
                omega-=0.033;
               passed=true;
               }
            }
            else{done=true;
                if(omega<-(Math.toRadians(270)))
                {
                omega-=0.001;
                x+=(int) (6*Math.cos(theta)) ;
                y-=(int)(5*Math.sin(theta));
                theta+=0.01;
                System.out.print(theta);
                done=true;
                }
                else{
                    y-=speed;
                    omega=(Math.toRadians(270));
                    done=true;
                    g.drawString("done", x, y);
                    
                    
                }
                
            }   
        }
     
      }
      else{
          moving++;
          if(moving>20){
              collision=false;
              moving=0;
          }
      }
    
    }
public void MoveW_E(Graphics g,boolean GO){
      
      if(!collision){
      if(x < (490)){
        x =  x + 10 ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            if(x<680){
              if(GO||x>=505){
                 //System.out.println(red+" "+x);
                 x+=10;
                 passed=true;
               }
            }
            else{
                
                x+=5;
                done=true;
            }   
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveE_W(Graphics g,boolean GO){
      
      if(!collision){
      if(x > (765)){
        x =  x - speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            if(x<=765){
              if(GO||x<=700){
                 //System.out.println(green+" "+x);
                 x-=speed;
                 passed=true;
                 //done=true;
               }
            }
            else{
                done=true;
                x-=speed;
            }
            
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveE_S(Graphics g,boolean GO){
      
      if(!collision){
      if(x >(765)){
        x =  x -speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            
              if(x>595){
              if(GO||x<=700){
                 //System.out.println(+" "+x);
                 x-=(int) (6*Math.cos(theta)) ;
                 y +=(int)(6*Math.sin(theta));
                 theta+=0.03;
                 omega-=0.03;
                 passed=true;
              }
            }
            else{
                   if(omega<-(Math.toRadians(270)))
                {
                omega-=0.02;
                done=true;
                x-=(int) (6*Math.cos(theta)) ;
                y+=(int)(8*Math.sin(theta));
                theta+=0.03;
                System.out.print(theta);
                }
                else{
                       done=true;
                       omega=Math.toRadians(270);
                    y+=speed;
                    
                }
                
               
            }   
        }     
      
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveE_N(Graphics g,boolean GO){
      
      if(!collision){
      if(x >(765)){
        x =  x -speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            
              if(x>680){
              if(GO||x<=700){
                 System.out.println(GO+" "+x);
                 x-=(int) (5*Math.cos(theta)) ;
                 y -=(int)(5*Math.sin(theta));
                 theta+=0.04;
                 omega+=0.03;
                 passed=true;
              }
            }
            else{
                if(omega<(Math.toRadians(90)))
                {
                omega+=0.07;
                done=true;
                x-=(int) (Math.cos(theta)) ;
                y-=(int)(5*Math.sin(theta));
                theta+=0.027;
                System.out.print(theta);
                }
                else{done=true;
                    y-=speed;
                    
                }
                
                
            }   
        }
      } 
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveS_N(Graphics g,boolean GO){
      
      if(!collision){
      if(y > (500)){
        y =  y - speed ;
        if(speed<10){
            speed+=1;
        }
        }
        else{
            if(y<=500){
              if(GO||y<=490){
                 System.out.println(GO+" "+x);
                 y-=speed;
                 done=true;
                 
               }
            }
            
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
      
    }
public void MoveS_W(Graphics g,boolean GO){
      
      if(!collision){
      if(y >(500)){
        y =  y -speed ;
        if(speed<10){
            speed+=1;
        }
        
        }
        else{
            
              if(y>=340){
              if(GO||y<=490){
                // System.out.println(red+" "+x);
                 x+=(int) (6*Math.cos(theta)) ;
                 y +=(int)(6*Math.sin(theta));
                 theta-=0.027;
                 omega-=0.04;
                 passed=true;
              }
            }
            else{
                 
                if(omega>(Math.toRadians(180)))
                {
                omega-=0.06;
                done=true;
                x+=(int) (6*Math.cos(theta)) ;
                y+=(int)(6*Math.sin(theta));
                theta-=0.03;
                System.out.print(theta);
                }
                else{
                    x-=speed;
                    
                }
                
                
            }   
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }
public void MoveS_E(Graphics g,boolean GO){
      
      if(!collision){
      if(y >(500)){
        y =  y -speed ;
        if(speed<10){
            speed+=1;
        }
        
        }
        else{
            
              if(y>=390){
              if(GO||y<=490){
                 System.out.println(GO+" "+x);
                 x+=(int) (6*Math.cos(theta)) ;
                 y +=(int)(6*Math.sin(theta));
                 theta+=0.035;
                 omega+=0.049;
              }
            }
            else{
                 if(omega>(Math.toRadians(360)))
                {
                omega+=0.04;
                done=true;
                x+=(int) (5*Math.cos(theta)) ;
                y+=(int)(5*Math.sin(theta));
                theta+=0.03;
                //System.out.print(theta);
                }
                else{
                       done=true;
                       omega=Math.toRadians(0);
                    
                    x+=speed;
                }
                
               
                
            }   
        }
      }
      else{
          moving++;
          if(moving>200){
              collision=false;
              moving=0;
          }
      }
    }


public void setAdjustX(int x){
    this.x =  x ; 
}
public void setAdjustY(int y){

      this.y = y;

}
public void setAdjustSpeed(int speed){
    this.speed = speed ;
}
public int getSpeed(){
    return this.speed ; 
}
public boolean getstate(){
    return done ; 
}
} 
