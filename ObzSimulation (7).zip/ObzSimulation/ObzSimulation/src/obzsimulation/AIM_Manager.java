/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Shape;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;

/**
 *
 * @author Boitshoko
 */
public class AIM_Manager {
    Graphics2D graphics;
    int time,robot,legtime,requests;
    boolean state,collision;
    ArrayList<Vehicle> cars;
    Deque<Vehicle> deque;
    
    public AIM_Manager(int robot){
        
        time=0;
        legtime=0;
        requests=0;
        this.robot=robot;
        state=true;
        
        cars = new ArrayList();
        deque = new LinkedList<Vehicle>();
	}
     public Rectangle bounds(int x,int y,int sizex,int sizey){
         /*
       switch (id) {
            case 1:  return(new Rectangle(560, 355, 80, 80));
            case 2:  return(new Rectangle(560, 275, 80, 80));
            case 3:  return(new Rectangle(640, 275, 80, 80));
            case 4:  return(new Rectangle(640, 355, 80, 80));
            default: return null;
       }*/
        return(new Rectangle(x,y,sizex,sizey));
    }
     
   public boolean Deque(){
       return deque.isEmpty();
   }
       

     
     public void checkCollision(Vehicle car){
       Rectangle r1 = car.bounds();
       
       for(int j=275;j<435;j=j+20){
           for(int i=560;i<720;i=i+20){
               //graphics.setColor(Color.white);
               //graphics.fillRect(i,j, 80, 80);
               Rectangle r2 = this.bounds(i,j,20,20);
               if (r1.intersects(r2)){
                  collision=true;
                  graphics.setColor(Color.white);
                  graphics.fillRect(i,j, 20, 20);
                  
                 }
           }
       }
     }
        
    public void count(){
        
        time++;
    }
    public boolean Done(Vehicle Car){
         Rectangle r1 = Car.bounds();
         Rectangle r2 = this.bounds(570,275,160,160);
         if(r1.intersects(r2)){
             Car.setIntersection(true);
         }
         if(!(r1.intersects(r2))&&Car.intersection){
         graphics.setColor(Color.WHITE);
          graphics.fillRect(50, 355, 80, 80);
          deque.remove(Car);
         return true;
         
         }
        
        return false;
    }
    public void update(Graphics g,Vehicle car,Boolean Go){
          graphics=(Graphics2D) g;
          //g.fillRect(490, 240, 290, 260);
          /*
          graphics.setColor(Color.WHITE);
          graphics.fillRect(560, 355, 80, 80);
          
          graphics.setColor(Color.yellow);
          graphics.fillRect(560, 275, 80, 80);
          
          graphics.setColor(Color.blue);
          graphics.fillRect(640, 275, 80, 80);*/
          
          
          
          Rectangle r1 = car.bounds();
        Rectangle r2 = this.bounds(560,275,160,160);
          this.checkCollision(car);
        //int Simulate = this.Simulate(car);
       // if(requests<=1){
       //     requests++;
            //graphics.setColor(Color.blue);
          //graphics.fillRect(r2.x, r2.y, 150, 150);legtime=0;
        if(car.Request()&&(car.requested==false)){
           graphics.setColor(Color.yellow);
          graphics.fillRect(r2.x, r2.y, 150, 150);legtime=0;
            //cars.add(car);
            deque.addLast(car);
            car.setrequstested(true);
        }//}
        
       
             
           // cars.remove(car);
            
        
        
       
  }
    public int Simulate(Vehicle car){
        Vehicle car2=new Vehicle(car.x,car.y,car.speed,car.id,car.direction,car.destination);
        int count=0;
        if(car.passed &&!(car.simulated)){
            car.setSimulated(true);
        while(!this.Done(car)){
            car2.Move(car2.direction, graphics, true);
            count++;
            if(count>100){
                break;
            }
            
        }}
        graphics.drawString(String.valueOf(count), 30, 30);
        return count;
    }
    public boolean getState(){
        return state;
    }
    public void CountTime(){
        requests=0;
        time++;
    }
    public void CountLeg(){
        legtime++;
    }
    public Vehicle GetFirst(){
        if(deque.isEmpty()){
        return null;
        }
        return deque.getFirst();
    }
}
