
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
public class RotateTransformed extends JPanel implements MouseListener {
    Ellipse2D e,e1;
  public void paint(Graphics g) {
    Graphics2D g2 = (Graphics2D) g;
 
    e = new Ellipse2D.Double(25, 10, 80, 130);
    addMouseListener(this);
g2.draw(e);
/*g2.rotate(45, 25+80/2, 10+130/2);*/
//AffineTransform at = AffineTransform.getRotateInstance(Math.atan2(25, 10),25+80/2, 10+130/2);
AffineTransform at = AffineTransform.getRotateInstance(45,25+80/2, 10+130/2);
//at.rotate(Math.toRadians(45));
//Shape s = at.createTransformedShape(e);
//Rectangle2D boundRect     = s.getBounds2D();
//e1 =  new Ellipse2D.Double(boundRect.getX(),boundRect.getY(),boundRect.getWidth(),boundRect.getHeight());;
g2.draw(at.createTransformedShape(e));
   
  }
 
  public static void main(String[] args) {
    JFrame frame = new JFrame();
    frame.add(new RotateTransformed());
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    frame.setSize(400, 400);
    frame.setVisible(true);
  }
 
@Override
public void mouseClicked(MouseEvent arg0) {
    Point p = new Point(arg0.getX(),arg0.getY());
    if(e.contains(p)){
        if(arg0.isMetaDown()){
            JOptionPane.showConfirmDialog(null,"Meso", "Meso Description", JOptionPane.PLAIN_MESSAGE);
        }
    }
     
}
 
@Override
public void mouseEntered(MouseEvent arg0) {
    // TODO Auto-generated method stub
     
}
 
@Override
public void mouseExited(MouseEvent arg0) {
    // TODO Auto-generated method stub
     
}
 
@Override
public void mousePressed(MouseEvent arg0) {
    // TODO Auto-generated method stub
     
}
 
@Override
public void mouseReleased(MouseEvent arg0) {
    // TODO Auto-generated method stub
     
}
}
