# Traffic-Simulator

![alt](https://github.com/Dna072/Traffic-Simulator/blob/master/resources/traffic_sim.jpg)

2D Traffic simulation of a crossed junction double road (with pedestrian crossing) traffic simulation with total of 10 traffic lights each with one minute transition time. Simulated vehicles have the ability to move and access all routes possible while avoiding possible collisions.
  

