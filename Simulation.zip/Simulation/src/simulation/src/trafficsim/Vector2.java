package trafficsim;

public class Vector2 {
	public int x, y;
	
	Vector2(int x, int y){
		this.x = x;
		this.y = y;
	}
}
