/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author mshsit002
 */
public class ObzSimulation extends JPanel implements ActionListener {
    
    BufferedImage Terrain  = null ; 
    
    BufferedImage Car      = null ; 
    boolean red =true;
    boolean t=true;
    TrafficLight traffic;
    Graphics2D graphics;
    Vehicle vehicle;
    
    int time = 0 ;
    
    int RobotTime = 10 ;
    
    
    
    int x = 800 ;
    
    int y = 330 ; 
    
    public void moveCarNje(){
        
        time = time+1 ; 
        if(x < (500)){
        x =  x + 10 ;
        }
        else{
            if(x<585){
              if(red){
                 System.out.println(red+" "+x);
               y+=3;
               x+=8;}
            }
            else{
                
                y+=5;
            }
            
            
        }
     
     }
    
    
    
    public void paintComponent(Graphics g){
    
      super.paintComponent(g);

        graphics  = (Graphics2D)g ; 

        Dimension size = new Dimension(Terrain.getWidth(null), Terrain.getHeight(null));

        setPreferredSize(size);
        
        setMinimumSize(size);

        setMaximumSize(size);

      setSize(size);
      
      graphics.drawImage(Terrain,0,0,null);
      
      graphics.drawImage(Car,(int)x,(int)y,null);  
      
      
      
      vehicle.MoveE_W(g, traffic.getState());
      traffic.update(g);
      traffic.CountTime();
     
      
      
      
     
     
    
      
      }
    

    public ObzSimulation() throws IOException{
    
      Terrain  = ImageIO.read(new File("C:\\Users\\Boitshoko\\Downloads\\ObzSimulation\\ObzSimulation\\src\\obzsimulation\\maxresdefault.jpg"));
      red=true;
        traffic=new TrafficLight();
      vehicle=new Vehicle(x,y,10);
      /*
      Car      = ImageIO.read(new File("C:\\Users\\Boitshoko\\Downloads\\ObzSimulation\\ObzSimulation\\src\\obzsimulation\\car3.png"));
      
      AffineTransform tx  = new AffineTransform();
      
      tx.scale(0.51,0.51);

      tx.rotate(0,Car.getWidth()/2,Car.getHeight());
      
      System.out.println(Car.getWidth());
      System.out.println(Car.getHeight());
      AffineTransformOp op = new AffineTransformOp(tx, AffineTransformOp.TYPE_BICUBIC);
       
      Car = op.filter(Car, null);
      
      */
      
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException, InterruptedException {
        // TODO code application logic here
        
        JFrame Jframe  =  new JFrame("Jesus Take The wheel"); 
        
        ObzSimulation simulation  = new ObzSimulation();
        
        Jframe.setContentPane(simulation);
        
        Jframe.setSize(1534,772);
        
        Jframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Jframe.addMouseListener(new MouseListener() {
        
        public void mousePressed(MouseEvent me) { }
        
        public void mouseReleased(MouseEvent me) { }
        
        public void mouseEntered(MouseEvent me) { }
        
        public void mouseExited(MouseEvent me) { }
        
        public void mouseClicked(MouseEvent me) { 
          
          int x = me.getX();
          
          int y = me.getY();
          
          System.out.println(("X:" + x + " Y:" + y)); 
        }
    });
        
        
        Jframe.setVisible(true);
        
        while(true){
        
            simulation.moveCarNje();
            
            simulation.repaint();
            
            
            
            Thread.sleep(100);
        
        }
        
        
        
     
        
        
        
        
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        
        
    }
    
}
