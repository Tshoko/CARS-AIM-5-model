/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Timer;

/**
 *
 * @author Boitshoko
 */
public class TrafficLight {
    Graphics2D graphics;
    int time;
    boolean state;
    public TrafficLight(){
        
        time=0;
	}
    
    public void update(Graphics g){
        graphics=(Graphics2D) g;
        if(time > 70){
          time=0;
          if(state){
              state=false;
          }
          else{
              state=true;
          }
      }
      else{
          if(state){
          graphics.setColor(Color.GREEN);
          graphics.fillRect(508, 360, 9, 75);
          
          graphics.setColor(Color.GREEN);
          graphics.fillRect(765, 271, 9, 75);
          
          graphics.setColor(Color.RED);
          graphics.fillRect(643, 483, 75, 9);
          
          graphics.setColor(Color.RED);
          graphics.fillRect(565, 222, 75, 9);
          }
          else{
              graphics.setColor(Color.RED);
              graphics.fillRect(508, 360, 9, 75);
              
              graphics.setColor(Color.RED);
              graphics.fillRect(765, 271, 9, 75);
              
              graphics.setColor(Color.GREEN);
              graphics.fillRect(643, 483, 75, 9);
          
              graphics.setColor(Color.GREEN);
              graphics.fillRect(565, 222, 75, 9);
          }
          
      }
    }
    public boolean getState(){
        return state;
    }
    public void CountTime(){
        time++;
    }
    

    
}

