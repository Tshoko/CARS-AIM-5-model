/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package obzsimulation;

import java.awt.Color;
import java.awt.Graphics;
import java.lang.Math.*;
/**
 *
 * @author Boitshoko
 */
public class Vehicle {
   int x ; 
    
    int y ;
    
    int width ;
    
    int height;
    boolean passed;
    int speed ;
    double theta;
    
    public Vehicle(int newx,int newy,int speed){
        x =  newx ;
        y = newy  ;
        speed=speed;
        theta=0;
        passed=false;
    }
    
    public void MoveW_S(Graphics g,boolean red){
      g.setColor(Color.red);
      g.fillOval((int)x,(int)y, 10,10);
      if(x < (500)){
        x =  x + 10 ;
        }
        else{
            if(x<585){
              if(red){
                 System.out.println(red+" "+x);
                 x+=(int) (4*Math.cos(theta)) ;
                 y +=(int)(4*Math.sin(theta));
                 theta+=0.03;
              }
            }
            else{
                
                y+=5;
            }   
        }  
    }
    
    
    public void MoveW_N(Graphics g,boolean red){
      g.setColor(Color.red);
      g.fillOval((int)x,(int)y, 10,10);
      if(x < (500)){
        x =  x + 10 ;
        passed=true;
        }
        else{
            if(x<680){
              if(red){
                 System.out.println(red+" "+x);
                 x+=(int) (6*Math.cos(theta)) ;
                 y -=(int)(6*Math.sin(theta));
                theta+=0.027;
               }
            }
            else{
                
                y-=5;
            }   
        }  
    }
public void MoveW_E(Graphics g,boolean red){
      g.setColor(Color.red);
      g.fillOval((int)x,(int)y, 10,10);
      if(x < (500)){
        x =  x + 10 ;
        
        }
        else{
            if(x<680){
              if(red){
                 System.out.println(red+" "+x);
                 x+=10;
               }
            }
            else{
                
                x+=5;
            }   
        }  
    }
public void MoveE_W(Graphics g,boolean red){
      g.setColor(Color.red);
      g.fillOval((int)x,(int)y, 10,10);
      if(x < (500)){
        x =  x - 10 ;
        
        }
        else{
            if(x<680){
              if(red){
                 System.out.println(red+" "+x);
                 x-=10;
               }
            }
            else{
                
                x-=5;
            }   
        }  
    }
} 
